import React, { useState } from 'react';
import { X, Heart, ShoppingBag, Check, ShieldCheck, Ruler, Truck, ArrowLeft } from 'lucide-react';
import { Product } from '../types';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, size: string, quantity: number) => void;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  isWishlisted,
  onToggleWishlist,
}) => {
  if (!product) return null;

  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'M');
  const [quantity, setQuantity] = useState<number>(1);
  const [showSizeGuide, setShowSizeGuide] = useState<boolean>(false);
  const [addedSuccess, setAddedSuccess] = useState<boolean>(false);

  const handleAdd = () => {
    onAddToCart(product, selectedSize, quantity);
    setAddedSuccess(true);
    setTimeout(() => {
      setAddedSuccess(false);
      onClose();
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 md:p-6">
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row my-auto max-h-[92vh]">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 text-stone-500 hover:text-stone-950 bg-white/80 backdrop-blur-md rounded-full shadow-sm hover:bg-white transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left Column: Visual Media Container */}
        <div className="md:w-1/2 bg-stone-100 relative min-h-[300px] md:min-h-full">
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-full object-cover max-h-[400px] md:max-h-none"
            referrerPolicy="no-referrer"
          />
          {product.badge && (
            <div className="absolute top-4 left-4 bg-stone-900 text-white text-xs font-semibold px-3 py-1 rounded-md">
              {product.badge}
            </div>
          )}
        </div>

        {/* Right Column: Contiguous Purchase Module */}
        <div className="md:w-1/2 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto">
          <div className="space-y-5">
            {/* Metadata Header */}
            <div>
              <div className="flex items-center justify-between text-xs text-stone-500 font-medium">
                <span>{product.category}</span>
                <span className="font-mono text-stone-400">SKU: {product.sku}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-stone-950 font-display mt-1">
                {product.name}
              </h2>
              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-2xl font-bold font-mono text-stone-900 tabular-nums">
                  ₹{product.price.toLocaleString('en-IN')}
                </span>
                <span className="text-xs text-stone-500">incl. of all taxes</span>
              </div>
            </div>

            {/* Color & Stock */}
            <div className="flex items-center justify-between text-xs py-2 border-y border-stone-100">
              <span className="text-stone-600">
                Color: <strong className="text-stone-900 font-semibold">{product.color}</strong>
              </span>
              <span className="font-medium">
                {product.stock > 0 ? (
                  <span className="text-emerald-700">In Stock ({product.stock} units available)</span>
                ) : (
                  <span className="text-red-600">Out of Stock</span>
                )}
              </span>
            </div>

            {/* Description */}
            <p className="text-sm text-stone-600 leading-relaxed">
              {product.description}
            </p>

            {/* Size Selector */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-stone-900">
                  Select Size
                </span>
                <button
                  type="button"
                  onClick={() => setShowSizeGuide(!showSizeGuide)}
                  className="text-xs text-stone-600 hover:text-stone-950 flex items-center gap-1 underline underline-offset-2 cursor-pointer font-medium"
                >
                  <Ruler className="w-3.5 h-3.5" />
                  <span>Size Guide</span>
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {product.sizes.map((sz) => {
                  const isSelected = selectedSize === sz;
                  return (
                    <button
                      key={sz}
                      type="button"
                      onClick={() => setSelectedSize(sz)}
                      className={`min-w-11 py-2 px-3 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                        isSelected
                          ? 'border-stone-950 bg-stone-950 text-white shadow-xs'
                          : 'border-stone-200 bg-white text-stone-800 hover:border-stone-400'
                      }`}
                    >
                      {sz}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Size Guide Drawer (Inline if opened) */}
            {showSizeGuide && (
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs space-y-2">
                <div className="font-bold text-stone-900">Standard Garment Dimensions (Inches)</div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left tabular-nums">
                    <thead>
                      <tr className="border-b border-stone-200 text-stone-500">
                        <th className="py-1">Size</th>
                        <th className="py-1">Chest</th>
                        <th className="py-1">Length</th>
                        <th className="py-1">Shoulder</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      <tr><td className="py-1 font-medium">S</td><td>38"</td><td>27.5"</td><td>18"</td></tr>
                      <tr><td className="py-1 font-medium">M</td><td>40"</td><td>28.5"</td><td>19"</td></tr>
                      <tr><td className="py-1 font-medium">L</td><td>42"</td><td>29.5"</td><td>20"</td></tr>
                      <tr><td className="py-1 font-medium">XL</td><td>44"</td><td>30.5"</td><td>21"</td></tr>
                      <tr><td className="py-1 font-medium">XXL</td><td>46"</td><td>31.5"</td><td>22"</td></tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Garment Details & Care */}
            <div className="grid grid-cols-2 gap-3 text-xs pt-2">
              <div className="bg-stone-50 p-2.5 rounded-lg border border-stone-100">
                <span className="text-stone-400 block text-[10px] uppercase font-bold">Fabric Material</span>
                <span className="font-medium text-stone-800">{product.material || '100% Combed Cotton'}</span>
              </div>
              <div className="bg-stone-50 p-2.5 rounded-lg border border-stone-100">
                <span className="text-stone-400 block text-[10px] uppercase font-bold">Fit Profile</span>
                <span className="font-medium text-stone-800">{product.fit || 'Structured Relaxed Fit'}</span>
              </div>
            </div>
          </div>

          {/* Action Row & Quantity */}
          <div className="pt-6 border-t border-stone-100 mt-6 space-y-3">
            <div className="flex items-center gap-3">
              {/* Quantity Selector */}
              <div className="flex items-center border border-stone-300 rounded-lg overflow-hidden bg-stone-50 shrink-0">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-2 text-stone-700 hover:bg-stone-200 transition-colors font-bold cursor-pointer"
                >
                  -
                </button>
                <span className="px-3 py-2 text-xs font-mono font-semibold tabular-nums text-stone-900">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="px-3 py-2 text-stone-700 hover:bg-stone-200 transition-colors font-bold cursor-pointer"
                >
                  +
                </button>
              </div>

              {/* Add to Bag Button */}
              <button
                type="button"
                onClick={handleAdd}
                disabled={product.stock === 0}
                className={`flex-1 py-3 px-5 rounded-lg font-semibold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm ${
                  product.stock === 0
                    ? 'bg-stone-300 text-stone-500 cursor-not-allowed'
                    : addedSuccess
                    ? 'bg-emerald-600 text-white'
                    : 'bg-stone-950 hover:bg-stone-800 text-white'
                }`}
              >
                {addedSuccess ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Added to Bag!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>Add to Bag · ₹{(product.price * quantity).toLocaleString('en-IN')}</span>
                  </>
                )}
              </button>

              {/* Wishlist Button */}
              <button
                type="button"
                onClick={() => onToggleWishlist(product)}
                className={`p-3 rounded-lg border transition-colors cursor-pointer shrink-0 ${
                  isWishlisted
                    ? 'border-red-500 bg-red-50 text-red-600'
                    : 'border-stone-300 hover:border-stone-900 text-stone-700'
                }`}
                aria-label="Save to wishlist"
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
              </button>
            </div>

            {/* Quick Guarantees */}
            <div className="flex items-center justify-between text-[11px] text-stone-500 pt-2">
              <span className="flex items-center gap-1">
                <Truck className="w-3.5 h-3.5 text-stone-700" />
                Dispatch within 24 Hours
              </span>
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-stone-700" />
                7-Day Size Exchanges
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
